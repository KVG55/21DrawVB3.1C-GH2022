﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace Draw
{
    partial class AboutBox1 : Form
    {
        public AboutBox1()
        {
            InitializeComponent();
          
          
        }

        private void AboutBox1_Load(object sender, EventArgs e)
        {
            try
            {
                label1.Text = "VaresVK Provider";
                label2.Text = "Version 1010";
                label3.Text = "This program are created and maid by KVG©.";


            }
            catch (Exception Exclamation)
            {
                // Report about others mistakes:
                MessageBox.Show(Exclamation.Message, "Mistake",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
