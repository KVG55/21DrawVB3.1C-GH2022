﻿using Draw.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Draw
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ShowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                richTextBox1.Text = Resources.TextFile1;

            }
            catch (Exception Исключение)
            {
                // Отчет о других ошибках:
                MessageBox.Show(Исключение.Message, "ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
    }
}
